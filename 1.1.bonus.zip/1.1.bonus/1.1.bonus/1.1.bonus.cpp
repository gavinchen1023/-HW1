#include "Bonus_BmpCommon.hpp"

#include <limits>

using namespace bonus;

void processAndSave(const Image& input, int width, int height,
    const std::string& label, const std::string& prefix) {
    Image resized = resizeNearest(input, width, height);
    printImageInfo(label + " resized image", resized);
    writeBmp24(prefix + "_" + label + "_resized.bmp", resized);

    Image rotated = rotate270Clockwise(resized);
    writeBmp24(prefix + "_" + label + "_rotated.bmp", rotated);

    interchangeChannels(rotated);
    writeBmp24(prefix + "_" + label + "_channels.bmp", rotated);

    std::cout << "  Saved resize, rotation, and channel results for "
        << label << ".\n";
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: Bonus1_DoubleHalf input.bmp output_prefix\n";
        return 1;
    }

    try {
        const Image input = readBmp24(argv[1]);
        printImageInfo("Original image", input);

        if (input.width > std::numeric_limits<int>::max() / 2 ||
            input.height > std::numeric_limits<int>::max() / 2) {
            throw std::runtime_error("Input is too large to double");
        }

        const std::string prefix = argv[2];
        processAndSave(input, input.width * 2, input.height * 2,
            "double", prefix);
        processAndSave(input, std::max(1, input.width / 2),
            std::max(1, input.height / 2), "half", prefix);
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
