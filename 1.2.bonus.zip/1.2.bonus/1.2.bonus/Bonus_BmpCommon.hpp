#ifndef BONUS_BMP_COMMON_HPP
#define BONUS_BMP_COMMON_HPP

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace bonus {

#pragma pack(push, 1)
struct BmpFileHeader {
    std::uint16_t type;
    std::uint32_t fileSize;
    std::uint16_t reserved1;
    std::uint16_t reserved2;
    std::uint32_t pixelOffset;
};

struct BmpInfoHeader {
    std::uint32_t headerSize;
    std::int32_t width;
    std::int32_t height;
    std::uint16_t planes;
    std::uint16_t bitsPerPixel;
    std::uint32_t compression;
    std::uint32_t imageSize;
    std::int32_t xPixelsPerMeter;
    std::int32_t yPixelsPerMeter;
    std::uint32_t colorsUsed;
    std::uint32_t importantColors;
};

struct Pixel {
    std::uint8_t b, g, r;
};
#pragma pack(pop)

static_assert(sizeof(BmpFileHeader) == 14);
static_assert(sizeof(BmpInfoHeader) == 40);
static_assert(sizeof(Pixel) == 3);

struct Image {
    int width = 0;
    int height = 0;
    std::vector<Pixel> pixels;

    Pixel &at(int x, int y) {
        return pixels[static_cast<std::size_t>(y) * width + x];
    }
    const Pixel &at(int x, int y) const {
        return pixels[static_cast<std::size_t>(y) * width + x];
    }
};

struct RowInfo {
    std::uint32_t beforePadding = 0;
    std::uint32_t padding = 0;
    std::uint32_t actual = 0;
    std::uint64_t bufferSize = 0;
};

inline RowInfo getRowInfo(int width, int height) {
    if (width <= 0 || height <= 0 ||
        static_cast<std::uint64_t>(width) * 3U >
            std::numeric_limits<std::uint32_t>::max()) {
        throw std::runtime_error("Invalid image dimensions");
    }
    RowInfo info;
    info.beforePadding = static_cast<std::uint32_t>(width) * 3U;
    info.padding = (4U - info.beforePadding % 4U) % 4U;
    info.actual = info.beforePadding + info.padding;
    info.bufferSize = static_cast<std::uint64_t>(info.actual) * height;
    return info;
}

inline void printImageInfo(const std::string &label, const Image &image) {
    const RowInfo info = getRowInfo(image.width, image.height);
    std::cout << label << '\n'
              << "  Width: " << image.width << '\n'
              << "  Height: " << image.height << '\n'
              << "  Bits per pixel: 24\n"
              << "  Row before padding: " << info.beforePadding << " bytes\n"
              << "  Padding per row: " << info.padding << " bytes\n"
              << "  Actual row size: " << info.actual << " bytes\n"
              << "  Image buffer size: " << info.bufferSize << " bytes\n";
}

inline Image readBmp24(const std::string &filename) {
    std::ifstream input(filename, std::ios::binary);
    if (!input) {
        throw std::runtime_error("Cannot open input file: " + filename);
    }

    BmpFileHeader fileHeader{};
    BmpInfoHeader infoHeader{};
    input.read(reinterpret_cast<char *>(&fileHeader), sizeof(fileHeader));
    input.read(reinterpret_cast<char *>(&infoHeader), sizeof(infoHeader));

    if (!input || fileHeader.type != 0x4D42 || infoHeader.headerSize < 40 ||
        infoHeader.width <= 0 || infoHeader.height == 0 || infoHeader.planes != 1 ||
        infoHeader.bitsPerPixel != 24 || infoHeader.compression != 0) {
        throw std::runtime_error("Input must be an uncompressed 24-bit BMP");
    }

    const bool bottomUp = infoHeader.height > 0;
    Image image;
    image.width = infoHeader.width;
    image.height = bottomUp ? infoHeader.height : -infoHeader.height;
    image.pixels.resize(static_cast<std::size_t>(image.width) * image.height);

    const RowInfo rowInfo = getRowInfo(image.width, image.height);
    std::vector<std::uint8_t> row(rowInfo.actual);
    input.seekg(fileHeader.pixelOffset, std::ios::beg);

    for (int fileRow = 0; fileRow < image.height; ++fileRow) {
        input.read(reinterpret_cast<char *>(row.data()), row.size());
        if (!input) {
            throw std::runtime_error("Unexpected end of BMP pixel data");
        }
        const int y = bottomUp ? image.height - 1 - fileRow : fileRow;
        for (int x = 0; x < image.width; ++x) {
            const std::size_t k = static_cast<std::size_t>(x) * 3;
            image.at(x, y) = Pixel{row[k], row[k + 1], row[k + 2]};
        }
    }
    return image;
}

inline void writeBmp24(const std::string &filename, const Image &image) {
    const RowInfo rowInfo = getRowInfo(image.width, image.height);
    const std::uint64_t fileSize64 = 54ULL + rowInfo.bufferSize;
    if (fileSize64 > std::numeric_limits<std::uint32_t>::max()) {
        throw std::runtime_error("Output BMP is too large");
    }

    BmpFileHeader fileHeader{};
    fileHeader.type = 0x4D42;
    fileHeader.fileSize = static_cast<std::uint32_t>(fileSize64);
    fileHeader.pixelOffset = 54;

    BmpInfoHeader infoHeader{};
    infoHeader.headerSize = 40;
    infoHeader.width = image.width;
    infoHeader.height = image.height;
    infoHeader.planes = 1;
    infoHeader.bitsPerPixel = 24;
    infoHeader.compression = 0;
    infoHeader.imageSize = static_cast<std::uint32_t>(rowInfo.bufferSize);
    infoHeader.xPixelsPerMeter = 2835;
    infoHeader.yPixelsPerMeter = 2835;

    std::ofstream output(filename, std::ios::binary);
    if (!output) {
        throw std::runtime_error("Cannot create output file: " + filename);
    }
    output.write(reinterpret_cast<const char *>(&fileHeader), sizeof(fileHeader));
    output.write(reinterpret_cast<const char *>(&infoHeader), sizeof(infoHeader));

    const std::uint8_t zeros[3] = {0, 0, 0};
    for (int y = image.height - 1; y >= 0; --y) {
        for (int x = 0; x < image.width; ++x) {
            const Pixel &pixel = image.at(x, y);
            output.write(reinterpret_cast<const char *>(&pixel), sizeof(Pixel));
        }
        output.write(reinterpret_cast<const char *>(zeros), rowInfo.padding);
    }
    if (!output) {
        throw std::runtime_error("Failed while writing: " + filename);
    }
}

inline Image resizeNearest(const Image &source, int newWidth, int newHeight) {
    if (newWidth <= 0 || newHeight <= 0) {
        throw std::runtime_error("Resize dimensions must be positive");
    }

    Image result;
    result.width = newWidth;
    result.height = newHeight;
    result.pixels.resize(static_cast<std::size_t>(newWidth) * newHeight);

    for (int y = 0; y < newHeight; ++y) {
        const int sourceY = static_cast<int>(
            static_cast<std::int64_t>(y) * source.height / newHeight);
        for (int x = 0; x < newWidth; ++x) {
            const int sourceX = static_cast<int>(
                static_cast<std::int64_t>(x) * source.width / newWidth);
            result.at(x, y) = source.at(sourceX, sourceY);
        }
    }
    return result;
}

inline Image rotate270Clockwise(const Image &source) {
    Image result;
    result.width = source.height;
    result.height = source.width;
    result.pixels.resize(source.pixels.size());

    for (int y = 0; y < source.height; ++y) {
        for (int x = 0; x < source.width; ++x) {
            result.at(y, source.width - 1 - x) = source.at(x, y);
        }
    }
    return result;
}

inline void interchangeChannels(Image &image) {
    for (Pixel &pixel : image.pixels) {
        const Pixel old = pixel;
        pixel.b = old.g; // old G -> new B
        pixel.g = old.r; // old R -> new G
        pixel.r = old.b; // old B -> new R
    }
}

inline Image rotateAndInterchange(const Image &source) {
    Image result = rotate270Clockwise(source);
    interchangeChannels(result);
    return result;
}

inline int parsePositiveInt(const char *text, const char *fieldName) {
    const std::string value(text);
    std::size_t used = 0;
    const long number = std::stol(value, &used);
    if (used != value.size() || number <= 0 ||
        number > std::numeric_limits<int>::max()) {
        throw std::runtime_error(std::string(fieldName) + " must be positive");
    }
    return static_cast<int>(number);
}

} // namespace bonus

#endif
