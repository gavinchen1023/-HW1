#include "Bonus_BmpCommon.hpp"

using namespace bonus;

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: Bonus2_4096 input.bmp output_prefix\n";
        return 1;
    }

    try {
        const Image input = readBmp24(argv[1]);
        const std::string prefix = argv[2];

        // std::vector allocates the large buffers dynamically on the heap.
        Image resized = resizeNearest(input, 4096, 4096);
        printImageInfo("4096x4096 resized image", resized);
        writeBmp24(prefix + "_4096_resized.bmp", resized);

        Image rotated = rotate270Clockwise(resized);
        writeBmp24(prefix + "_4096_rotated.bmp", rotated);

        interchangeChannels(rotated);
        writeBmp24(prefix + "_4096_channels.bmp", rotated);

        std::cout << "Saved all 4096x4096 results.\n";
    }
    catch (const std::bad_alloc&) {
        std::cerr << "Error: insufficient heap memory for 4096x4096 images.\n";
        return 1;
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
