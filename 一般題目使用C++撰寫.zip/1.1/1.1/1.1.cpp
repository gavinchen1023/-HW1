#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#pragma pack(push, 1)
struct BmpFileHeader {
    std::uint16_t type;
    std::uint32_t fileSize;
    std::uint16_t reserved1;
    std::uint16_t reserved2;
    std::uint32_t pixelOffset;
};

struct BmpInfoHeader {
    std::uint32_t headerSize;
    std::int32_t width;
    std::int32_t height;
    std::uint16_t planes;
    std::uint16_t bitsPerPixel;
    std::uint32_t compression;
    std::uint32_t imageSize;
    std::int32_t xPixelsPerMeter;
    std::int32_t yPixelsPerMeter;
    std::uint32_t colorsUsed;
    std::uint32_t importantColors;
};

struct Pixel {
    std::uint8_t b;
    std::uint8_t g;
    std::uint8_t r;
};
#pragma pack(pop)

static_assert(sizeof(BmpFileHeader) == 14);
static_assert(sizeof(BmpInfoHeader) == 40);
static_assert(sizeof(Pixel) == 3);

struct Image {
    int width = 0;
    int height = 0;
    std::vector<Pixel> pixels; // top-to-bottom, left-to-right

    Pixel& at(int x, int y) {
        return pixels[static_cast<std::size_t>(y) * width + x];
    }
};

struct HeaderReport {
    int width = 0;
    int height = 0;
    int bitsPerPixel = 0;
    std::uint32_t rowBeforePadding = 0;
    std::uint32_t paddingPerRow = 0;
    std::uint32_t actualRowSize = 0;
    std::uint64_t totalBufferSize = 0;
};

HeaderReport makeReport(int width, int height, int bitsPerPixel) {
    HeaderReport report;
    report.width = width;
    report.height = height;
    report.bitsPerPixel = bitsPerPixel;
    report.rowBeforePadding =
        static_cast<std::uint32_t>(width) * bitsPerPixel / 8U;
    report.paddingPerRow = (4U - report.rowBeforePadding % 4U) % 4U;
    report.actualRowSize = report.rowBeforePadding + report.paddingPerRow;
    report.totalBufferSize =
        static_cast<std::uint64_t>(report.actualRowSize) * height;
    return report;
}

void printReport(const HeaderReport& report) {
    std::cout << "Image width: " << report.width << '\n'
        << "Image height: " << report.height << '\n'
        << "Bits per pixel: " << report.bitsPerPixel << '\n'
        << "Row size before padding: " << report.rowBeforePadding
        << " bytes\n"
        << "Padding bytes per row: " << report.paddingPerRow << " bytes\n"
        << "Actual row size including padding: " << report.actualRowSize
        << " bytes\n"
        << "Total image buffer size: " << report.totalBufferSize
        << " bytes\n";
}

Image readBmp24(const std::string& filename, HeaderReport& report) {
    std::ifstream input(filename, std::ios::binary);
    if (!input) {
        throw std::runtime_error("Cannot open input file: " + filename);
    }

    BmpFileHeader fileHeader{};
    BmpInfoHeader infoHeader{};
    input.read(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    input.read(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    if (!input || fileHeader.type != 0x4D42) {
        throw std::runtime_error("The input is not a valid BMP file");
    }
    if (infoHeader.headerSize < 40 || infoHeader.width <= 0 ||
        infoHeader.height == 0 || infoHeader.planes != 1 ||
        infoHeader.bitsPerPixel != 24 || infoHeader.compression != 0) {
        throw std::runtime_error("Only uncompressed 24-bit BMP is supported");
    }

    const bool bottomUp = infoHeader.height > 0;
    const int width = infoHeader.width;
    const int height = bottomUp ? infoHeader.height : -infoHeader.height;
    report = makeReport(width, height, infoHeader.bitsPerPixel);

    Image image;
    image.width = width;
    image.height = height;
    image.pixels.resize(static_cast<std::size_t>(width) * height);

    input.seekg(fileHeader.pixelOffset, std::ios::beg);
    std::vector<std::uint8_t> row(report.actualRowSize);

    for (int fileRow = 0; fileRow < height; ++fileRow) {
        input.read(reinterpret_cast<char*>(row.data()), row.size());
        if (!input) {
            throw std::runtime_error("Unexpected end of BMP pixel data");
        }

        const int y = bottomUp ? height - 1 - fileRow : fileRow;
        for (int x = 0; x < width; ++x) {
            const std::size_t index = static_cast<std::size_t>(x) * 3;
            image.at(x, y) = Pixel{ row[index], row[index + 1], row[index + 2] };
        }
    }
    return image;
}

void writeBmp24(const std::string& filename, const Image& image) {
    const HeaderReport report = makeReport(image.width, image.height, 24);

    BmpFileHeader fileHeader{};
    fileHeader.type = 0x4D42;
    fileHeader.pixelOffset = sizeof(BmpFileHeader) + sizeof(BmpInfoHeader);
    fileHeader.fileSize = static_cast<std::uint32_t>(
        fileHeader.pixelOffset + report.totalBufferSize);

    BmpInfoHeader infoHeader{};
    infoHeader.headerSize = sizeof(BmpInfoHeader);
    infoHeader.width = image.width;
    infoHeader.height = image.height; // positive means bottom-up
    infoHeader.planes = 1;
    infoHeader.bitsPerPixel = 24;
    infoHeader.compression = 0;
    infoHeader.imageSize = static_cast<std::uint32_t>(report.totalBufferSize);
    infoHeader.xPixelsPerMeter = 2835;
    infoHeader.yPixelsPerMeter = 2835;

    std::ofstream output(filename, std::ios::binary);
    if (!output) {
        throw std::runtime_error("Cannot create output file: " + filename);
    }

    output.write(reinterpret_cast<const char*>(&fileHeader), sizeof(fileHeader));
    output.write(reinterpret_cast<const char*>(&infoHeader), sizeof(infoHeader));

    const std::uint8_t padding[3] = { 0, 0, 0 };
    for (int y = image.height - 1; y >= 0; --y) {
        for (int x = 0; x < image.width; ++x) {
            const Pixel& pixel = image.pixels[
                static_cast<std::size_t>(y) * image.width + x];
            output.write(reinterpret_cast<const char*>(&pixel), sizeof(Pixel));
        }
        output.write(reinterpret_cast<const char*>(padding), report.paddingPerRow);
    }

    if (!output) {
        throw std::runtime_error("Failed while writing the BMP file");
    }
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: Q1_BMP_ReadWrite input.bmp output.bmp\n";
        return 1;
    }

    try {
        HeaderReport report;
        const Image image = readBmp24(argv[1], report);
        printReport(report);
        writeBmp24(argv[2], image);
        std::cout << "BMP read/write completed: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
