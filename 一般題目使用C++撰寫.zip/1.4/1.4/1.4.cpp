#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#pragma pack(push, 1)
struct BmpFileHeader {
    std::uint16_t type;
    std::uint32_t fileSize;
    std::uint16_t reserved1;
    std::uint16_t reserved2;
    std::uint32_t pixelOffset;
};
struct BmpInfoHeader {
    std::uint32_t headerSize;
    std::int32_t width;
    std::int32_t height;
    std::uint16_t planes;
    std::uint16_t bitsPerPixel;
    std::uint32_t compression;
    std::uint32_t imageSize;
    std::int32_t xPixelsPerMeter;
    std::int32_t yPixelsPerMeter;
    std::uint32_t colorsUsed;
    std::uint32_t importantColors;
};
struct Pixel {
    std::uint8_t b, g, r;
};
#pragma pack(pop)

struct Image {
    int width = 0;
    int height = 0;
    std::vector<Pixel> pixels;

    Pixel& at(int x, int y) {
        return pixels[static_cast<std::size_t>(y) * width + x];
    }
    const Pixel& at(int x, int y) const {
        return pixels[static_cast<std::size_t>(y) * width + x];
    }
};

std::uint32_t rowSizeWithPadding(int width) {
    const std::uint32_t raw = static_cast<std::uint32_t>(width) * 3U;
    return raw + (4U - raw % 4U) % 4U;
}

Image readBmp24(const std::string& filename) {
    std::ifstream input(filename, std::ios::binary);
    BmpFileHeader fileHeader{};
    BmpInfoHeader infoHeader{};
    input.read(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    input.read(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    if (!input || fileHeader.type != 0x4D42 || infoHeader.headerSize < 40 ||
        infoHeader.width <= 0 || infoHeader.height == 0 || infoHeader.planes != 1 ||
        infoHeader.bitsPerPixel != 24 || infoHeader.compression != 0) {
        throw std::runtime_error("Input must be an uncompressed 24-bit BMP");
    }

    const bool bottomUp = infoHeader.height > 0;
    Image image;
    image.width = infoHeader.width;
    image.height = bottomUp ? infoHeader.height : -infoHeader.height;
    image.pixels.resize(static_cast<std::size_t>(image.width) * image.height);

    const std::uint32_t rowSize = rowSizeWithPadding(image.width);
    std::vector<std::uint8_t> row(rowSize);
    input.seekg(fileHeader.pixelOffset, std::ios::beg);

    for (int fileRow = 0; fileRow < image.height; ++fileRow) {
        input.read(reinterpret_cast<char*>(row.data()), row.size());
        if (!input) {
            throw std::runtime_error("Unexpected end of BMP data");
        }
        const int y = bottomUp ? image.height - 1 - fileRow : fileRow;
        for (int x = 0; x < image.width; ++x) {
            const std::size_t k = static_cast<std::size_t>(x) * 3;
            image.at(x, y) = Pixel{ row[k], row[k + 1], row[k + 2] };
        }
    }
    return image;
}

void writeBmp24(const std::string& filename, const Image& image) {
    const std::uint32_t rowSize = rowSizeWithPadding(image.width);
    const std::uint32_t rawRowSize = static_cast<std::uint32_t>(image.width) * 3U;
    const std::uint32_t padding = rowSize - rawRowSize;
    const std::uint32_t imageSize = rowSize * image.height;

    BmpFileHeader fileHeader{ 0x4D42, 54U + imageSize, 0, 0, 54 };
    BmpInfoHeader infoHeader{};
    infoHeader.headerSize = 40;
    infoHeader.width = image.width;
    infoHeader.height = image.height;
    infoHeader.planes = 1;
    infoHeader.bitsPerPixel = 24;
    infoHeader.imageSize = imageSize;
    infoHeader.xPixelsPerMeter = 2835;
    infoHeader.yPixelsPerMeter = 2835;

    std::ofstream output(filename, std::ios::binary);
    if (!output) {
        throw std::runtime_error("Cannot create output file");
    }
    output.write(reinterpret_cast<const char*>(&fileHeader), sizeof(fileHeader));
    output.write(reinterpret_cast<const char*>(&infoHeader), sizeof(infoHeader));

    const std::uint8_t zeros[3] = { 0, 0, 0 };
    for (int y = image.height - 1; y >= 0; --y) {
        for (int x = 0; x < image.width; ++x) {
            const Pixel& p = image.at(x, y);
            output.write(reinterpret_cast<const char*>(&p), sizeof(Pixel));
        }
        output.write(reinterpret_cast<const char*>(zeros), padding);
    }
}

Image rotate270Clockwise(const Image& source) {
    Image result;
    result.width = source.height;
    result.height = source.width;
    result.pixels.resize(static_cast<std::size_t>(result.width) * result.height);

    for (int y = 0; y < source.height; ++y) {
        for (int x = 0; x < source.width; ++x) {
            result.at(y, source.width - 1 - x) = source.at(x, y);
        }
    }
    return result;
}

void interchangeChannels(Image& image) {
    for (Pixel& pixel : image.pixels) {
        const Pixel old = pixel;
        pixel.b = old.g;
        pixel.g = old.r;
        pixel.r = old.b;
    }
}

int parseRepeatCount(const char* text) {
    const std::string value(text);
    std::size_t used = 0;
    const long number = std::stol(value, &used);
    if (used != value.size() || number <= 0 ||
        number > std::numeric_limits<int>::max()) {
        throw std::runtime_error("Repeat count must be a positive integer");
    }
    return static_cast<int>(number);
}

int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 4) {
        std::cerr << "Usage: Q4_ExecutionTime input.bmp output.bmp [repeat]\n";
        return 1;
    }

    try {
        const int repeat = argc == 4 ? parseRepeatCount(argv[3]) : 30;

        // File reading is intentionally outside the timed region.
        const Image input = readBmp24(argv[1]);

        double totalMilliseconds = 0.0;
        double minimumMilliseconds = std::numeric_limits<double>::max();
        Image result;

        for (int run = 0; run < repeat; ++run) {
            const auto start = std::chrono::steady_clock::now();

            Image rotated = rotate270Clockwise(input);
            interchangeChannels(rotated);

            const auto finish = std::chrono::steady_clock::now();
            const double elapsed =
                std::chrono::duration<double, std::milli>(finish - start).count();

            totalMilliseconds += elapsed;
            if (elapsed < minimumMilliseconds) {
                minimumMilliseconds = elapsed;
            }
            result = std::move(rotated);
        }

        // File writing is intentionally outside the timed region.
        writeBmp24(argv[2], result);

        std::cout << std::fixed << std::setprecision(3)
            << "Image size: " << input.width << 'x' << input.height << '\n'
            << "Repeat count: " << repeat << '\n'
            << "Timed operations: output allocation + 270-degree clockwise "
            "rotation + channel interchange\n"
            << "Excluded operations: BMP reading and BMP writing\n"
            << "Average time: " << totalMilliseconds / repeat << " ms\n"
            << "Minimum time: " << minimumMilliseconds << " ms\n"
            << "Output file: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
