#include "Bonus_BmpCommon.hpp"

#include <chrono>
#include <fstream>
#include <iomanip>

using namespace bonus;

struct TimingResult {
    double averageMs = 0.0;
    double minimumMs = 0.0;
    Image finalImage;
};

struct SummaryRow {
    int size = 0;
    std::uint64_t pixels = 0;
    double averageMs = 0.0;
    double minimumMs = 0.0;
    double msPerMegapixel = 0.0;
    double relativePixels = 0.0;
    double relativeTime = 0.0;
};

TimingResult measure(const Image& source, int repeat) {
    // One untimed warm-up reduces one-time cache/setup effects.
    Image warmup = rotateAndInterchange(source);

    double total = 0.0;
    double minimum = std::numeric_limits<double>::max();
    Image result;

    for (int run = 0; run < repeat; ++run) {
        const auto start = std::chrono::steady_clock::now();
        result = rotateAndInterchange(source);
        const auto finish = std::chrono::steady_clock::now();

        const double milliseconds =
            std::chrono::duration<double, std::milli>(finish - start).count();
        total += milliseconds;
        minimum = std::min(minimum, milliseconds);
    }

    return TimingResult{ total / repeat, minimum, std::move(result) };
}

int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 5) {
        std::cerr << "Usage: Bonus3_Benchmark input.bmp output_prefix "
            "[repeat=30] [save_images=1]\n";
        return 1;
    }

    try {
        const int repeat = argc >= 4 ? parsePositiveInt(argv[3], "repeat") : 30;
        const bool saveImages = argc < 5 || std::string(argv[4]) != "0";
        const std::string prefix = argv[2];
        const Image input = readBmp24(argv[1]);
        const int sizes[] = { 512, 1024, 2048, 4096 };

        std::ofstream csv(prefix + "_timing.csv");
        if (!csv) {
            throw std::runtime_error("Cannot create timing CSV");
        }
        csv << "size,pixels,average_ms,minimum_ms,ms_per_megapixel,"
            "relative_pixels,relative_time\n";

        std::cout << std::fixed << std::setprecision(3)
            << "\nBONUS 3 - EXECUTION TIME COMPARISON\n"
            << "Four image sizes will be processed in order.\n";

        double baseTime = 0.0;
        const double basePixels = 512.0 * 512.0;
        std::vector<SummaryRow> summary;

        for (int stage = 0; stage < 4; ++stage) {
            const int size = sizes[stage];
            const RowInfo rowInfo = getRowInfo(size, size);
            const std::string sizeText = std::to_string(size);
            const std::string resizedFile =
                prefix + "_" + sizeText + "_resized.bmp";
            const std::string rotatedFile =
                prefix + "_" + sizeText + "_rotated.bmp";
            const std::string channelsFile =
                prefix + "_" + sizeText + "_channels.bmp";

            std::cout << "\n============================================================\n"
                << "STAGE " << stage + 1 << " / 4\n"
                << "Image size: " << size << 'x' << size << '\n'
                << "------------------------------------------------------------\n"
                << "Pixel count: "
                << static_cast<std::uint64_t>(size) * size << '\n'
                << "Bits per pixel: 24\n"
                << "Row size before padding: " << rowInfo.beforePadding
                << " bytes\n"
                << "Padding bytes per row: " << rowInfo.padding
                << " bytes\n"
                << "Actual row size: " << rowInfo.actual << " bytes\n"
                << "Image buffer size: " << rowInfo.bufferSize << " bytes\n"
                << "Repeat count: " << repeat << '\n'
                << "Timed operations: output allocation + 270-degree "
                "clockwise rotation + channel interchange\n"
                << "Excluded operations: resize, BMP reading, BMP writing, "
                "CSV output, console output\n"
                << "------------------------------------------------------------\n"
                << "Processing...\n";

            Image resized = resizeNearest(input, size, size);
            Image rotatedForSaving;
            if (saveImages) {
                writeBmp24(resizedFile, resized);
                rotatedForSaving = rotate270Clockwise(resized);
                writeBmp24(rotatedFile, rotatedForSaving);
            }

            TimingResult timing = measure(resized, repeat);
            if (baseTime == 0.0) {
                baseTime = timing.averageMs;
            }

            if (saveImages) {
                writeBmp24(channelsFile, timing.finalImage);
            }

            const double pixels = static_cast<double>(size) * size;
            const double msPerMegapixel = timing.averageMs / (pixels / 1.0e6);
            const double relativePixels = pixels / basePixels;
            const double relativeTime = timing.averageMs / baseTime;

            summary.push_back(SummaryRow{
                size,
                static_cast<std::uint64_t>(pixels),
                timing.averageMs,
                timing.minimumMs,
                msPerMegapixel,
                relativePixels,
                relativeTime });

            std::cout << "Average time: " << timing.averageMs << " ms\n"
                << "Minimum time: " << timing.minimumMs << " ms\n"
                << "Time per megapixel: " << msPerMegapixel << " ms\n"
                << "Relative pixel count: " << relativePixels << " x\n"
                << "Relative execution time: " << relativeTime << " x\n";

            if (saveImages) {
                std::cout << "Output resized image: " << resizedFile << '\n'
                    << "Output rotated image: " << rotatedFile << '\n'
                    << "Output channel image: " << channelsFile << '\n';
            }
            else {
                std::cout << "Output images: not saved (save_images=0)\n";
            }

            std::cout << "Stage " << stage + 1 << " completed.\n"
                << "============================================================\n";
            if (stage < 3) {
                std::cout << "Proceeding to the next image size...\n";
            }

            csv << size << 'x' << size << ','
                << static_cast<std::uint64_t>(pixels) << ','
                << timing.averageMs << ',' << timing.minimumMs << ','
                << msPerMegapixel << ',' << relativePixels << ','
                << relativeTime << '\n';
        }

        std::cout << "\nFINAL COMPARISON\n"
            << "================================================================"
            "================\n"
            << std::left << std::setw(12) << "Size"
            << std::right << std::setw(14) << "Pixels"
            << std::setw(14) << "Avg (ms)"
            << std::setw(14) << "Min (ms)"
            << std::setw(14) << "ms/MPixel"
            << std::setw(12) << "Time x" << '\n'
            << "----------------------------------------------------------------"
            "----------------\n";

        for (const SummaryRow& row : summary) {
            const std::string sizeLabel =
                std::to_string(row.size) + "x" + std::to_string(row.size);
            std::cout << std::left << std::setw(12) << sizeLabel
                << std::right << std::setw(14) << row.pixels
                << std::setw(14) << row.averageMs
                << std::setw(14) << row.minimumMs
                << std::setw(14) << row.msPerMegapixel
                << std::setw(12) << row.relativeTime << '\n';
        }

        std::cout << "================================================================"
            "================\n"
            << "CSV saved to: " << prefix << "_timing.csv\n"
            << "Images saved: " << (saveImages ? "yes" : "no") << '\n';
    }
    catch (const std::bad_alloc&) {
        std::cerr << "Error: insufficient heap memory for benchmark image.\n";
        return 1;
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
