#include <opencv2/opencv.hpp>

#include <iostream>
#include <stdexcept>
#include <vector>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: OpenCV_Q3_ChannelInterchange "
            "rotated.bmp channel_output.bmp\n";
        return 1;
    }

    try {
        const cv::Mat rotated = cv::imread(argv[1], cv::IMREAD_COLOR);
        if (rotated.empty()) {
            throw std::runtime_error("OpenCV could not read the rotated image");
        }

        // OpenCV stores color pixels in B,G,R order.
        std::vector<cv::Mat> bgr;
        cv::split(rotated, bgr);

        // Assignment mapping:
        // old R -> new G, old G -> new B, old B -> new R.
        // Therefore new B,G,R = old G,R,B.
        cv::Mat result;
        cv::merge(std::vector<cv::Mat>{bgr[1], bgr[2], bgr[0]}, result);

        if (!cv::imwrite(argv[2], result)) {
            throw std::runtime_error("OpenCV could not write the result image");
        }

        std::cout << "Channel mapping: R->G, G->B, B->R\n"
            << "Image size: " << result.cols << 'x' << result.rows << '\n'
            << "Output file: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
