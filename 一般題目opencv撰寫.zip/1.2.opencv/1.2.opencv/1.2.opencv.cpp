#include <opencv2/opencv.hpp>

#include <iostream>
#include <stdexcept>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: OpenCV_Q2_Rotate270 input.bmp rotated.bmp\n";
        return 1;
    }

    try {
        const cv::Mat input = cv::imread(argv[1], cv::IMREAD_COLOR);
        if (input.empty()) {
            throw std::runtime_error("OpenCV could not read the input image");
        }

        cv::Mat rotated;
        // 270 degrees clockwise is equal to 90 degrees counterclockwise.
        cv::rotate(input, rotated, cv::ROTATE_90_COUNTERCLOCKWISE);

        if (!cv::imwrite(argv[2], rotated)) {
            throw std::runtime_error("OpenCV could not write the rotated image");
        }

        std::cout << "Input size: " << input.cols << 'x' << input.rows << '\n'
            << "Output size: " << rotated.cols << 'x' << rotated.rows << '\n'
            << "Rotation: 270 degrees clockwise "
            "(90 degrees counterclockwise)\n"
            << "Output file: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
