#include <opencv2/opencv.hpp>

#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

#pragma pack(push, 1)
struct BmpFileHeader {
    std::uint16_t type;
    std::uint32_t fileSize;
    std::uint16_t reserved1;
    std::uint16_t reserved2;
    std::uint32_t pixelOffset;
};

struct BmpInfoHeader {
    std::uint32_t headerSize;
    std::int32_t width;
    std::int32_t height;
    std::uint16_t planes;
    std::uint16_t bitsPerPixel;
    std::uint32_t compression;
    std::uint32_t imageSize;
    std::int32_t xPixelsPerMeter;
    std::int32_t yPixelsPerMeter;
    std::uint32_t colorsUsed;
    std::uint32_t importantColors;
};
#pragma pack(pop)

static_assert(sizeof(BmpFileHeader) == 14);
static_assert(sizeof(BmpInfoHeader) == 40);

struct BmpReport {
    int width = 0;
    int height = 0;
    int bitsPerPixel = 0;
    std::uint64_t rowBeforePadding = 0;
    std::uint64_t paddingPerRow = 0;
    std::uint64_t actualRowSize = 0;
    std::uint64_t totalImageBufferSize = 0;
};

BmpReport readBmpHeader(const std::string& filename) {
    std::ifstream input(filename, std::ios::binary);
    if (!input) {
        throw std::runtime_error("Cannot open input file: " + filename);
    }

    BmpFileHeader fileHeader{};
    BmpInfoHeader infoHeader{};
    input.read(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    input.read(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    if (!input || fileHeader.type != 0x4D42 || infoHeader.headerSize < 40 ||
        infoHeader.width <= 0 || infoHeader.height == 0 || infoHeader.planes != 1) {
        throw std::runtime_error("The input is not a supported BMP file");
    }

    BmpReport report;
    report.width = infoHeader.width;
    report.height = infoHeader.height > 0 ? infoHeader.height : -infoHeader.height;
    report.bitsPerPixel = infoHeader.bitsPerPixel;
    report.rowBeforePadding =
        (static_cast<std::uint64_t>(report.width) * report.bitsPerPixel + 7U) / 8U;
    report.paddingPerRow = (4U - report.rowBeforePadding % 4U) % 4U;
    report.actualRowSize = report.rowBeforePadding + report.paddingPerRow;
    report.totalImageBufferSize = report.actualRowSize * report.height;
    return report;
}

void printReport(const BmpReport& report) {
    std::cout << "Image width: " << report.width << '\n'
        << "Image height: " << report.height << '\n'
        << "Bits per pixel: " << report.bitsPerPixel << '\n'
        << "Row size before padding: " << report.rowBeforePadding
        << " bytes\n"
        << "Padding bytes per row: " << report.paddingPerRow << " bytes\n"
        << "Actual row size including padding: " << report.actualRowSize
        << " bytes\n"
        << "Total image buffer size: " << report.totalImageBufferSize
        << " bytes\n";
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: OpenCV_Q1_ReadWrite input.bmp output.bmp\n";
        return 1;
    }

    try {
        // Read the required values directly from the BMP header.
        const BmpReport report = readBmpHeader(argv[1]);
        printReport(report);

        // OpenCV performs image decoding and encoding in this version.
        const cv::Mat image = cv::imread(argv[1], cv::IMREAD_UNCHANGED);
        if (image.empty()) {
            throw std::runtime_error("OpenCV could not decode the input BMP");
        }
        if (!cv::imwrite(argv[2], image)) {
            throw std::runtime_error("OpenCV could not write the output BMP");
        }

        std::cout << "OpenCV matrix: " << image.cols << 'x' << image.rows
            << ", channels=" << image.channels() << '\n'
            << "Output file: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
