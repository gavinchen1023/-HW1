#include <opencv2/opencv.hpp>

#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

cv::Mat rotateAndInterchange(const cv::Mat& input) {
    cv::Mat rotated;
    cv::rotate(input, rotated, cv::ROTATE_90_COUNTERCLOCKWISE);

    std::vector<cv::Mat> bgr;
    cv::split(rotated, bgr);

    cv::Mat result;
    cv::merge(std::vector<cv::Mat>{bgr[1], bgr[2], bgr[0]}, result);
    return result;
}

int parsePositiveInt(const char* text) {
    const std::string value(text);
    std::size_t used = 0;
    const long number = std::stol(value, &used);
    if (used != value.size() || number <= 0 ||
        number > std::numeric_limits<int>::max()) {
        throw std::runtime_error("Repeat count must be a positive integer");
    }
    return static_cast<int>(number);
}

int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 4) {
        std::cerr << "Usage: OpenCV_Q4_ExecutionTime input.bmp output.bmp "
            "[repeat=30]\n";
        return 1;
    }

    try {
        const int repeat = argc == 4 ? parsePositiveInt(argv[3]) : 30;

        // Disk reading is intentionally outside the timed region.
        const cv::Mat input = cv::imread(argv[1], cv::IMREAD_COLOR);
        if (input.empty()) {
            throw std::runtime_error("OpenCV could not read the input image");
        }

        // Untimed warm-up reduces first-run initialization effects.
        cv::Mat result = rotateAndInterchange(input);

        double totalMilliseconds = 0.0;
        double minimumMilliseconds = std::numeric_limits<double>::max();

        for (int run = 0; run < repeat; ++run) {
            const auto start = std::chrono::steady_clock::now();

            result = rotateAndInterchange(input);

            const auto finish = std::chrono::steady_clock::now();
            const double elapsed =
                std::chrono::duration<double, std::milli>(finish - start).count();
            totalMilliseconds += elapsed;
            minimumMilliseconds = std::min(minimumMilliseconds, elapsed);
        }

        // Disk writing is intentionally outside the timed region.
        if (!cv::imwrite(argv[2], result)) {
            throw std::runtime_error("OpenCV could not write the output image");
        }

        std::cout << std::fixed << std::setprecision(3)
            << "Image size: " << input.cols << 'x' << input.rows << '\n'
            << "Repeat count: " << repeat << '\n'
            << "Timed operations: OpenCV rotation + split + merge\n"
            << "Excluded operations: imread, imwrite, console output, warm-up\n"
            << "Average time: " << totalMilliseconds / repeat << " ms\n"
            << "Minimum time: " << minimumMilliseconds << " ms\n"
            << "Output file: " << argv[2] << '\n';
    }
    catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
